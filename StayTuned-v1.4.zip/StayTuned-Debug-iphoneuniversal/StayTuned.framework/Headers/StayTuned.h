//
//  StayTuned.h
//  StayTuned
//
//  Created by Kevin Morais on 28/04/2019.
//  Copyright © 2019 StayTuned. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for StayTuned.
FOUNDATION_EXPORT double StayTunedVersionNumber;

//! Project version string for StayTuned.
FOUNDATION_EXPORT const unsigned char StayTunedVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StayTuned/PublicHeader.h>


